from setuptools import setup, find_packages

setup(
    name="cuartorepo",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Camiloriverea25",                         # Tu nombre
    author_email="jcr9825@gmail.com",                 # Tu correo electrónico
    url="https://github.com/camilorivera25/cuartorepo",     # URL del proyecto
)